package com.example.guii;
public interface Payable {
    public double calculateTotalAmount();
}
