public interface Payable {
    public double calculateTotalAmount();
}
