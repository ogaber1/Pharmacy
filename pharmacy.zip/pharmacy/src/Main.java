public class Main {
    public static void main(String[] args) {//driving will be done here but still not implemented.
        }
    }
