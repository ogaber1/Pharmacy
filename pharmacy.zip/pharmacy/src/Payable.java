public interface Payable {
    public boolean processPayment();
    public double calculateTotalAmount();
}
